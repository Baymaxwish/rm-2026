# 路径跟随功能使用说明

## 功能说明

此功能允许你在 RViz 中交互式地绘制路径，然后机器人会自动跟随这条路径行驶。

## 使用步骤

### 1. 启动导航系统

首先确保导航系统已经启动：

```bash
cd /home/baymaxwish/fzsd2025
source install/setup.bash
./nav.sh
```

### 2. 启动路径跟随工具

在新的终端中：

```bash
cd /home/baymaxwish/fzsd2025
source install/setup.bash
ros2 launch nav2_command_handler path_follower_launch.py
```

### 3. 在 RViz 中绘制路径

1. 在 RViz 顶部工具栏找到 **"Publish Point"** 工具（或按快捷键 `P`）
2. 在地图上依次点击你想要机器人经过的点
3. 每点击一次，会添加一个路径点
4. 你可以在 RViz 中看到路径预览（紫色线条）

### 4. 发布路径让机器人跟随

在运行 `interactive_path_drawer.py` 的终端中：
- **按 Enter 键**：发布当前绘制的路径，机器人开始跟随
- **按 c 键**：清除当前路径，重新绘制
- **按 q 键**：退出程序

### 5. 观察机器人运动

机器人会自动跟随你绘制的路径运动，在终端中可以看到：
- 剩余距离
- 当前速度
- 完成状态

## RViz 配置

为了更好地可视化，建议在 RViz 中添加以下显示项：

1. **Path** - 话题: `/preview_path` (路径预览，灰色)
2. **Path** - 话题: `/current_following_path` (当前跟随路径，绿色)
3. **Path** - 话题: `/red_standard_robot1/local_plan` (局部规划路径，红色)
4. **PointStamped** - 话题: `/red_standard_robot1/lookahead_point` (前瞻点)

## 仅使用路径跟随节点（编程方式）

如果你想通过编程方式发布路径：

```bash
ros2 run nav2_command_handler path_follower_node --ros-args -p robot_namespace:=red_standard_robot1
```

然后发布 `nav_msgs/Path` 消息到 `/drawn_path` 话题。

## Python 示例代码

```python
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped

class PathPublisher(Node):
    def __init__(self):
        super().__init__('path_publisher')
        self.publisher = self.create_publisher(Path, '/drawn_path', 10)
        
    def publish_example_path(self):
        path = Path()
        path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        
        # 添加路径点
        points = [
            (0.0, 0.0),
            (1.0, 0.0),
            (2.0, 1.0),
            (3.0, 1.0),
        ]
        
        for x, y in points:
            pose = PoseStamped()
            pose.header = path.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.orientation.w = 1.0
            path.poses.append(pose)
        
        self.publisher.publish(path)
        self.get_logger().info('路径已发布')
```

## 故障排除

### 问题：机器人不移动
- 检查导航系统是否正常启动
- 检查 `/red_standard_robot1/follow_path` action 服务器是否可用
- 确保路径至少包含 2 个点

### 问题：路径点击不响应
- 确认 RViz 中已选择 "Publish Point" 工具
- 检查 `/clicked_point` 话题是否有数据发布

### 问题：机器人偏离路径
- 调整控制器参数（在 nav2_params.yaml 中）
- 检查地图定位是否准确
- 减小路径点之间的间距

## 高级功能

### 保存和加载路径

可以将绘制的路径保存为文件：

```bash
# 保存路径
ros2 topic echo /drawn_path > my_path.txt

# 或使用 rosbag
ros2 bag record /drawn_path
```

### 调整控制器参数

编辑 `pb2025_nav_bringup/config/reality/nav2_params.yaml`：

```yaml
FollowPath:
  plugin: "pb_omni_pid_pursuit_controller::OmniPidPursuitController"
  translation_kp: 3.0  # 位置比例增益
  lookahead_dist: 0.3  # 前瞻距离
  max_translation_speed: 3.0  # 最大线速度
```
