#!/bin/bash

# 快速启动指南
# 此脚本显示如何使用路径跟随功能

cat << 'EOF'
╔═══════════════════════════════════════════════════════════════╗
║           路径跟随功能 - 快速启动指南                         ║
╚═══════════════════════════════════════════════════════════════╝

🚀 方法一：交互式绘制路径（推荐新手）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  启动导航系统（终端1）：
   cd /home/baymaxwish/fzsd2025
   ./nav.sh

2️⃣  启动路径跟随工具（终端2）：
   cd /home/baymaxwish/fzsd2025/src/fzsd2025_sentry_nav/nav2_command_handler
   ./start_path_follower.sh

3️⃣  在 RViz 中查看地图并绘制路径：
   • 确认 RViz 中已显示地图（rmul_2025.pgm）
   • 地图话题：/red_standard_robot1/map 或 /map
   • 点击顶部工具栏的 "Publish Point" 按钮（或按 P 键）
   • 在地图上依次点击你想要的路径点
   • 看到路径预览（灰色线条）连接这些点

4️⃣  发布路径（在终端2中）：
   • 按 Enter 键 - 发布路径，机器人开始移动
   • 按 c 键 - 清除路径，重新绘制
   • 按 q 键 - 退出程序

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔧 方法二：编程方式发布路径（适合开发者）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  启动导航系统（终端1）：
   cd /home/baymaxwish/fzsd2025
   ./nav.sh

2️⃣  启动路径跟随节点（终端2）：
   cd /home/baymaxwish/fzsd2025
   source install/setup.bash
   ros2 run nav2_command_handler path_follower_node

3️⃣  发布示例路径（终端3）：
   cd /home/baymaxwish/fzsd2025
   source install/setup.bash
   
   # 发布预设路径
   ros2 run nav2_command_handler publish_path_example.py
   
   # 或者使用 ros2 topic pub 手动发布
   ros2 topic pub /drawn_path nav_msgs/msg/Path "{...}"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 RViz 可视化配置（重要！）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 必须显示的（用于绘制路径）：
Display Type    | Topic                                | 说明
----------------|--------------------------------------|------------------
Map             | /red_standard_robot1/map 或 /map     | 地图（rmul_2025.pgm）
RobotModel      | robot_description                    | 机器人模型
TF              | /tf                                  | 坐标变换

📍 建议添加以下显示项（用于观察路径跟随）：
Display Type    | Topic                                | Color
----------------|--------------------------------------|-------
Path            | /preview_path                        | 灰色（路径预览）
Path            | /current_following_path              | 绿色（当前路径）
Path            | /red_standard_robot1/local_plan      | 红色（局部规划）
Path            | /red_standard_robot1/global_plan     | 黄色（全局规划）
PointStamped    | /red_standard_robot1/lookahead_point | 红点（前瞻点）

⚙️  如何添加显示项：
   1. 点击 RViz 左下角 "Add" 按钮
   2. 选择显示类型（Map、Path、PointStamped 等）
   3. 设置对应的 Topic
   4. 调整颜色和透明度

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛠️  常用命令
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 查看话题
ros2 topic list | grep path

# 查看路径消息
ros2 topic echo /drawn_path

# 查看 follow_path action 状态
ros2 action list

# 取消当前路径跟随
ros2 action send_goal /red_standard_robot1/follow_path \
  nav2_msgs/action/FollowPath "{}" --feedback

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❓ 故障排除
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

问题：机器人不移动
解决：
  1. 检查 follow_path action 是否可用：
     ros2 action list | grep follow_path
  2. 查看控制器日志：
     ros2 topic echo /red_standard_robot1/controller_server/transition_event
  3. 确保路径至少有 2 个点

问题：路径绘制无响应
解决：
  1. 确认已选择 "Publish Point" 工具
  2. 检查话题：ros2 topic echo /clicked_point
  3. 重启 interactive_path_drawer.py

问题：机器人偏离路径
解决：
  1. 减小路径点间距（增加点的数量）
  2. 调整控制器参数（lookahead_dist）
  3. 检查定位精度

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 相关文件
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• 详细文档：README_PATH_FOLLOWER.md
• 启动文件：launch/path_follower_launch.py
• 绘制工具：scripts/interactive_path_drawer.py
• 示例代码：scripts/publish_path_example.py
• 控制器参数：pb2025_nav_bringup/config/reality/nav2_params.yaml

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 提示：
  • 建议先在仿真环境中测试路径
  • 路径点不要太密集，间隔 0.3-0.5 米为宜
  • 避免路径经过障碍物
  • 可以在移动过程中重新发布新路径

╚═══════════════════════════════════════════════════════════════╝
EOF
