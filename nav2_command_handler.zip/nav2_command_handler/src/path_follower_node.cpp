#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/path.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/follow_path.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include <memory>

class PathFollowerNode : public rclcpp::Node
{
public:
  using FollowPath = nav2_msgs::action::FollowPath;
  using GoalHandleFollowPath = rclcpp_action::ClientGoalHandle<FollowPath>;

  PathFollowerNode() : Node("path_follower_node")
  {
    // 声明参数
    this->declare_parameter("robot_namespace", "red_standard_robot1");
    robot_namespace_ = this->get_parameter("robot_namespace").as_string();

    // 订阅手绘路径
    path_subscriber_ = this->create_subscription<nav_msgs::msg::Path>(
      "/drawn_path", 10,
      std::bind(&PathFollowerNode::path_callback, this, std::placeholders::_1));

    // 创建 FollowPath action 客户端
    std::string action_name = "/" + robot_namespace_ + "/follow_path";
    follow_path_client_ = rclcpp_action::create_client<FollowPath>(this, action_name);

    // 发布当前跟随的路径（用于可视化）
    current_path_publisher_ = this->create_publisher<nav_msgs::msg::Path>(
      "/current_following_path", 10);

    RCLCPP_INFO(this->get_logger(), "路径跟随节点已启动");
    RCLCPP_INFO(this->get_logger(), "等待接收手绘路径，请在 RViz 中使用 'Publish Point' 工具绘制路径");
    RCLCPP_INFO(this->get_logger(), "或发布 nav_msgs/Path 消息到 /drawn_path 话题");
  }

private:
  void path_callback(const nav_msgs::msg::Path::SharedPtr msg)
  {
    if (msg->poses.empty()) {
      RCLCPP_WARN(this->get_logger(), "接收到空路径，忽略");
      return;
    }

    RCLCPP_INFO(this->get_logger(), "接收到路径，包含 %zu 个点", msg->poses.size());
    
    // 发布路径用于可视化
    current_path_publisher_->publish(*msg);

    // 等待 action 服务器
    if (!follow_path_client_->wait_for_action_server(std::chrono::seconds(5))) {
      RCLCPP_ERROR(this->get_logger(), "Action 服务器不可用！");
      return;
    }

    // 创建并发送目标
    auto goal_msg = FollowPath::Goal();
    goal_msg.path = *msg;
    goal_msg.controller_id = "FollowPath";  // 使用配置的控制器

    RCLCPP_INFO(this->get_logger(), "开始跟随路径...");

    auto send_goal_options = rclcpp_action::Client<FollowPath>::SendGoalOptions();
    
    // 目标响应回调
    send_goal_options.goal_response_callback =
      [this](const GoalHandleFollowPath::SharedPtr & goal_handle) {
        if (!goal_handle) {
          RCLCPP_ERROR(this->get_logger(), "目标被服务器拒绝");
        } else {
          RCLCPP_INFO(this->get_logger(), "目标被服务器接受，开始执行路径跟随");
        }
      };

    // 反馈回调
    send_goal_options.feedback_callback =
      [this](GoalHandleFollowPath::SharedPtr,
             const std::shared_ptr<const FollowPath::Feedback> feedback) {
        RCLCPP_INFO_THROTTLE(
          this->get_logger(), *this->get_clock(), 2000,
          "剩余距离: %.2f 米, 速度: %.2f m/s", 
          feedback->distance_to_goal,
          feedback->speed);
      };

    // 结果回调
    send_goal_options.result_callback =
      [this](const GoalHandleFollowPath::WrappedResult & result) {
        switch (result.code) {
          case rclcpp_action::ResultCode::SUCCEEDED:
            RCLCPP_INFO(this->get_logger(), "路径跟随成功完成！");
            break;
          case rclcpp_action::ResultCode::ABORTED:
            RCLCPP_ERROR(this->get_logger(), "路径跟随被中止");
            break;
          case rclcpp_action::ResultCode::CANCELED:
            RCLCPP_WARN(this->get_logger(), "路径跟随被取消");
            break;
          default:
            RCLCPP_ERROR(this->get_logger(), "未知结果代码");
            break;
        }
      };

    follow_path_client_->async_send_goal(goal_msg, send_goal_options);
  }

  std::string robot_namespace_;
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_subscriber_;
  rclcpp_action::Client<FollowPath>::SharedPtr follow_path_client_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr current_path_publisher_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<PathFollowerNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
