#!/bin/bash

# 路径跟随功能快速启动脚本

echo "======================================"
echo "    路径跟随功能启动脚本"
echo "======================================"
echo ""

# 检查是否已经 source
if [ -z "$ROS_DISTRO" ]; then
    echo "正在 source ROS 环境..."
    source /opt/ros/humble/setup.bash
    source /home/baymaxwish/fzsd2025/install/setup.bash
else
    echo "ROS 环境已配置: $ROS_DISTRO"
fi

echo ""
echo "启动路径跟随工具..."
echo ""
echo "使用说明："
echo "  1. 在 RViz 中选择 'Publish Point' 工具"
echo "  2. 在地图上点击绘制路径"
echo "  3. 按 Enter 键发布路径"
echo "  4. 按 c 键清除路径"
echo "  5. 按 q 键退出"
echo ""
echo "======================================"
echo ""

ros2 launch nav2_command_handler path_follower_launch.py
