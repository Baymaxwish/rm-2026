#!/bin/bash

# RViz 地图和路径绘制检查清单

echo "╔════════════════════════════════════════════════════════════╗"
echo "║        路径绘制功能 - 启动前检查清单                      ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# 检查地图文件
echo "📍 检查 1: 地图文件"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
MAP_PGM="/home/baymaxwish/fzsd2025/src/fzsd2025_sentry_nav/pb2025_nav_bringup/map/reality/rmul_2025.pgm"
MAP_YAML="/home/baymaxwish/fzsd2025/src/fzsd2025_sentry_nav/pb2025_nav_bringup/map/reality/rmul_2025.yaml"

if [ -f "$MAP_PGM" ]; then
    echo "✅ 地图文件存在: rmul_2025.pgm"
    SIZE=$(du -h "$MAP_PGM" | cut -f1)
    echo "   大小: $SIZE"
else
    echo "❌ 地图文件不存在: $MAP_PGM"
fi

if [ -f "$MAP_YAML" ]; then
    echo "✅ 地图配置存在: rmul_2025.yaml"
    echo "   配置内容:"
    cat "$MAP_YAML" | sed 's/^/   /'
else
    echo "❌ 地图配置不存在: $MAP_YAML"
fi

echo ""

# 检查 ROS 环境
echo "🔧 检查 2: ROS 环境"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -n "$ROS_DISTRO" ]; then
    echo "✅ ROS 环境已配置: $ROS_DISTRO"
else
    echo "❌ ROS 环境未配置"
    echo "   请运行: source /opt/ros/humble/setup.bash"
fi

if [ -f "/home/baymaxwish/fzsd2025/install/setup.bash" ]; then
    echo "✅ 工作空间已编译"
else
    echo "❌ 工作空间未编译"
    echo "   请运行: cd /home/baymaxwish/fzsd2025/src && colcon build"
fi

echo ""

# 检查可执行文件
echo "📦 检查 3: 可执行文件"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "/home/baymaxwish/fzsd2025/src/install/nav2_command_handler/lib/nav2_command_handler/path_follower_node" ]; then
    echo "✅ path_follower_node 已编译"
else
    echo "❌ path_follower_node 未找到"
fi

if [ -f "/home/baymaxwish/fzsd2025/src/install/nav2_command_handler/lib/nav2_command_handler/interactive_path_drawer.py" ]; then
    echo "✅ interactive_path_drawer.py 已安装"
else
    echo "❌ interactive_path_drawer.py 未找到"
fi

echo ""

# 检查导航系统是否运行
echo "🚀 检查 4: 导航系统状态"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Source ROS if needed
if [ -z "$ROS_DISTRO" ]; then
    source /opt/ros/humble/setup.bash 2>/dev/null
    source /home/baymaxwish/fzsd2025/install/setup.bash 2>/dev/null
fi

# 检查关键节点
if ros2 node list 2>/dev/null | grep -q "controller_server"; then
    echo "✅ 导航系统正在运行"
    echo "   发现节点:"
    ros2 node list 2>/dev/null | grep -E "(map_server|controller|planner)" | sed 's/^/   - /'
else
    echo "⚠️  导航系统未运行"
    echo "   请先运行: cd /home/baymaxwish/fzsd2025 && ./nav.sh"
fi

echo ""

# 检查话题
echo "📡 检查 5: 必需话题"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

check_topic() {
    if ros2 topic list 2>/dev/null | grep -q "$1"; then
        echo "✅ $2: $1"
    else
        echo "⚠️  $2: $1 (未发布)"
    fi
}

check_topic "/map\|/red_standard_robot1/map" "地图话题"
check_topic "/clicked_point" "点击话题"
check_topic "/tf" "坐标变换"

echo ""

# 检查 Action 服务器
echo "⚙️  检查 6: Action 服务器"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if ros2 action list 2>/dev/null | grep -q "follow_path"; then
    echo "✅ follow_path action 可用"
    ros2 action list 2>/dev/null | grep follow_path | sed 's/^/   - /'
else
    echo "⚠️  follow_path action 未找到"
    echo "   请确保导航系统已启动"
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                     检查完成                               ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# 给出建议
echo "📝 下一步操作建议："
echo ""

if ros2 node list 2>/dev/null | grep -q "controller_server"; then
    echo "✅ 系统就绪！可以开始绘制路径："
    echo ""
    echo "   终端1（已运行导航）: ./nav.sh"
    echo "   终端2（启动绘制工具）:"
    echo "      cd /home/baymaxwish/fzsd2025/src/fzsd2025_sentry_nav/nav2_command_handler"
    echo "      ./start_path_follower.sh"
    echo ""
    echo "   然后在 RViz 中："
    echo "   1. 点击 'Publish Point' 工具（或按 P 键）"
    echo "   2. 在地图（rmul_2025.pgm）上点击绘制路径"
    echo "   3. 在终端2按 Enter 发布路径"
else
    echo "⚠️  请按以下顺序启动："
    echo ""
    echo "   步骤1 - 终端1："
    echo "      cd /home/baymaxwish/fzsd2025"
    echo "      ./nav.sh"
    echo ""
    echo "   步骤2 - 等待 RViz 打开并显示地图"
    echo ""
    echo "   步骤3 - 终端2："
    echo "      cd /home/baymaxwish/fzsd2025/src/fzsd2025_sentry_nav/nav2_command_handler"
    echo "      ./start_path_follower.sh"
    echo ""
    echo "   步骤4 - 在 RViz 中绘制路径"
fi

echo ""
echo "📖 详细教程: cat DRAWING_GUIDE.md"
echo "❓ 快速指南: ./QUICK_START.sh"
echo ""
