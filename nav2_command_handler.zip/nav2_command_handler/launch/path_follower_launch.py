#!/usr/bin/env python3
"""
路径跟随系统启动文件
同时启动路径绘制工具和路径跟随节点
"""

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    # 声明参数
    declare_robot_namespace_cmd = DeclareLaunchArgument(
        'robot_namespace',
        default_value='red_standard_robot1',
        description='Robot namespace'
    )
    
    declare_frame_id_cmd = DeclareLaunchArgument(
        'frame_id',
        default_value='map',
        description='Frame ID for path'
    )
    
    # 配置变量
    robot_namespace = LaunchConfiguration('robot_namespace')
    frame_id = LaunchConfiguration('frame_id')
    
    # 交互式路径绘制节点
    path_drawer_node = Node(
        package='nav2_command_handler',
        executable='interactive_path_drawer.py',
        name='interactive_path_drawer',
        output='screen',
        parameters=[{
            'frame_id': frame_id,
        }],
        emulate_tty=True,
    )
    
    # 路径跟随节点
    path_follower_node = Node(
        package='nav2_command_handler',
        executable='path_follower_node',
        name='path_follower_node',
        output='screen',
        parameters=[{
            'robot_namespace': robot_namespace,
        }],
    )
    
    ld = LaunchDescription()
    
    # 添加声明的参数
    ld.add_action(declare_robot_namespace_cmd)
    ld.add_action(declare_frame_id_cmd)
    
    # 添加节点
    ld.add_action(path_drawer_node)
    ld.add_action(path_follower_node)
    
    return ld
