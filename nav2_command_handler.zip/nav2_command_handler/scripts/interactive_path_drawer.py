#!/usr/bin/env python3
"""
交互式路径绘制工具
使用方法：
1. 在 RViz 中添加 'PublishPoint' 工具
2. 运行此节点
3. 在 RViz 中点击地图上的点来绘制路径
4. 按 Enter 发布完整路径
5. 按 'c' 清除当前路径
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped, PoseStamped
from nav_msgs.msg import Path
from std_msgs.msg import Header
import sys
import select
import termios
import tty


class InteractivePathDrawer(Node):
    def __init__(self):
        super().__init__('interactive_path_drawer')
        
        # 声明参数
        self.declare_parameter('frame_id', 'map')
        self.frame_id = self.get_parameter('frame_id').as_string()
        
        # 订阅点击的点
        self.point_subscriber = self.create_subscription(
            PointStamped,
            '/clicked_point',
            self.point_callback,
            10
        )
        
        # 发布路径
        self.path_publisher = self.create_publisher(
            Path,
            '/drawn_path',
            10
        )
        
        # 发布路径用于预览
        self.preview_path_publisher = self.create_publisher(
            Path,
            '/preview_path',
            10
        )
        
        # 存储路径点
        self.path_points = []
        
        self.get_logger().info('交互式路径绘制工具已启动')
        self.get_logger().info('使用方法：')
        self.get_logger().info('  1. 在 RViz 中使用 "Publish Point" 工具点击地图')
        self.get_logger().info('  2. 按 Enter 键发布完整路径')
        self.get_logger().info('  3. 按 "c" 键清除当前路径')
        self.get_logger().info('  4. 按 "q" 键退出')
        
        # 创建定时器用于检查键盘输入
        self.timer = self.create_timer(0.1, self.check_keyboard)
        
        # 保存终端设置
        self.old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
    
    def __del__(self):
        # 恢复终端设置
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_settings)
    
    def point_callback(self, msg):
        """接收点击的点"""
        # 创建 PoseStamped
        pose = PoseStamped()
        pose.header = msg.header
        pose.pose.position = msg.point
        pose.pose.orientation.w = 1.0  # 默认朝向
        
        self.path_points.append(pose)
        
        self.get_logger().info(
            f'添加点 #{len(self.path_points)}: '
            f'({msg.point.x:.2f}, {msg.point.y:.2f}, {msg.point.z:.2f})'
        )
        
        # 发布预览路径
        self.publish_preview()
    
    def publish_preview(self):
        """发布预览路径"""
        if len(self.path_points) < 2:
            return
        
        path = Path()
        path.header.frame_id = self.frame_id
        path.header.stamp = self.get_clock().now().to_msg()
        path.poses = self.path_points
        
        self.preview_path_publisher.publish(path)
    
    def publish_path(self):
        """发布完整路径供机器人跟随"""
        if len(self.path_points) < 2:
            self.get_logger().warn('路径至少需要2个点！当前只有 %d 个点' % len(self.path_points))
            return
        
        path = Path()
        path.header.frame_id = self.frame_id
        path.header.stamp = self.get_clock().now().to_msg()
        path.poses = self.path_points
        
        self.path_publisher.publish(path)
        
        self.get_logger().info(f'已发布包含 {len(self.path_points)} 个点的路径')
        self.get_logger().info('机器人将开始跟随此路径')
    
    def clear_path(self):
        """清除当前路径"""
        self.path_points = []
        self.get_logger().info('路径已清除')
    
    def check_keyboard(self):
        """检查键盘输入"""
        if select.select([sys.stdin], [], [], 0)[0]:
            key = sys.stdin.read(1)
            
            if key == '\n' or key == '\r':  # Enter
                self.get_logger().info('发布路径...')
                self.publish_path()
            elif key.lower() == 'c':  # Clear
                self.clear_path()
            elif key.lower() == 'q':  # Quit
                self.get_logger().info('退出程序')
                rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = InteractivePathDrawer()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # 恢复终端设置
        if 'node' in locals():
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, node.old_settings)
        rclpy.shutdown()


if __name__ == '__main__':
    main()
