#!/usr/bin/env python3
"""
编程方式发布路径示例
此脚本演示如何通过代码创建并发布路径
"""

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import math


class PathPublisherExample(Node):
    def __init__(self):
        super().__init__('path_publisher_example')
        
        self.publisher = self.create_publisher(Path, '/drawn_path', 10)
        
        # 等待一会让系统准备好
        self.create_timer(2.0, self.publish_path)
        
        self.get_logger().info('路径发布示例节点已启动')
    
    def create_straight_line_path(self, start_x, start_y, end_x, end_y, num_points=10):
        """创建直线路径"""
        path = Path()
        path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        
        for i in range(num_points):
            t = i / (num_points - 1)
            x = start_x + t * (end_x - start_x)
            y = start_y + t * (end_y - start_y)
            
            pose = PoseStamped()
            pose.header = path.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = 0.0
            
            # 计算朝向
            if i < num_points - 1:
                dx = (end_x - start_x) / (num_points - 1)
                dy = (end_y - start_y) / (num_points - 1)
                yaw = math.atan2(dy, dx)
            else:
                yaw = 0.0
            
            pose.pose.orientation.z = math.sin(yaw / 2)
            pose.pose.orientation.w = math.cos(yaw / 2)
            
            path.poses.append(pose)
        
        return path
    
    def create_circle_path(self, center_x, center_y, radius, num_points=20):
        """创建圆形路径"""
        path = Path()
        path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        
        for i in range(num_points):
            angle = 2 * math.pi * i / num_points
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            
            pose = PoseStamped()
            pose.header = path.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = 0.0
            
            # 切向朝向
            tangent_angle = angle + math.pi / 2
            pose.pose.orientation.z = math.sin(tangent_angle / 2)
            pose.pose.orientation.w = math.cos(tangent_angle / 2)
            
            path.poses.append(pose)
        
        return path
    
    def create_square_path(self, center_x, center_y, size, num_points_per_side=5):
        """创建正方形路径"""
        path = Path()
        path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        
        half_size = size / 2
        corners = [
            (center_x - half_size, center_y - half_size),
            (center_x + half_size, center_y - half_size),
            (center_x + half_size, center_y + half_size),
            (center_x - half_size, center_y + half_size),
            (center_x - half_size, center_y - half_size),  # 回到起点
        ]
        
        for i in range(len(corners) - 1):
            start = corners[i]
            end = corners[i + 1]
            
            for j in range(num_points_per_side):
                t = j / num_points_per_side
                x = start[0] + t * (end[0] - start[0])
                y = start[1] + t * (end[1] - start[1])
                
                pose = PoseStamped()
                pose.header = path.header
                pose.pose.position.x = x
                pose.pose.position.y = y
                pose.pose.position.z = 0.0
                
                # 计算朝向
                dx = end[0] - start[0]
                dy = end[1] - start[1]
                yaw = math.atan2(dy, dx)
                
                pose.pose.orientation.z = math.sin(yaw / 2)
                pose.pose.orientation.w = math.cos(yaw / 2)
                
                path.poses.append(pose)
        
        return path
    
    def publish_path(self):
        """发布路径"""
        self.get_logger().info('选择要发布的路径类型：')
        self.get_logger().info('1. 直线路径')
        self.get_logger().info('2. 圆形路径')
        self.get_logger().info('3. 正方形路径')
        
        # 这里默认发布直线路径
        # 你可以根据需要修改
        path = self.create_straight_line_path(0.0, 0.0, 3.0, 3.0, num_points=15)
        # path = self.create_circle_path(0.0, 0.0, 2.0, num_points=30)
        # path = self.create_square_path(0.0, 0.0, 2.0, num_points_per_side=8)
        
        self.publisher.publish(path)
        
        self.get_logger().info(f'已发布包含 {len(path.poses)} 个点的路径')
        self.get_logger().info('机器人应该开始移动了')
        
        # 只发布一次
        self.destroy_timer(self.timer)


def main(args=None):
    rclpy.init(args=args)
    
    node = PathPublisherExample()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
